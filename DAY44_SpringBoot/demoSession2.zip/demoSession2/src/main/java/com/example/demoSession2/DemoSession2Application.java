package com.example.demoSession2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoSession2Application {

	public static void main(String[] args) {
		SpringApplication.run(DemoSession2Application.class, args);
	}

}
