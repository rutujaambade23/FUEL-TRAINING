package com.example.demowithoutweblaywer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemowithoutweblaywerApplicationTests {

	@Test
	void contextLoads() {
	}

}
