package com.example.demowithoutweblaywer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemowithoutweblaywerApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemowithoutweblaywerApplication.class, args);
	}

}
