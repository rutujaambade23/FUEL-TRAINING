package com.example.demoMovieSport;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoMovieSportApplicationTests {

	@Test
	void contextLoads() {
	}

}
