package com.example.demoMovieSport;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoMovieSportApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoMovieSportApplication.class, args);
	}

}
