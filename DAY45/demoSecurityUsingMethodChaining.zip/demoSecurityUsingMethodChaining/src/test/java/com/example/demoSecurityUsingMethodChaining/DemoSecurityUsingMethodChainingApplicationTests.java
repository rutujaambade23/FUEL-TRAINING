package com.example.demoSecurityUsingMethodChaining;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoSecurityUsingMethodChainingApplicationTests {

	@Test
	void contextLoads() {
	}

}
